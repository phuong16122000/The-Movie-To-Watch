# CP1404 Assignment 1 - Movies To Watch
Assignment 1 for CP1404/CP1804/CP5632, IT@JCU

By: _Your Name_

This repo contains starter files including a Python file and two CSV files.  
`movies.csv` is a data file for you to use.  
`movies_backup.csv` is the same data, but not to be used...    
This is here as a backup to copy the data from if you need it again.

Edit this README file, replacing the instructions (including this paragraph) with your own assignment details.  
At the end of the project, complete the very brief project reflection below by answering the questions (replace the `answer...` parts).  
Note: If you use the free WakaTime service on your own machine, you can track exactly how long you spent in code.  
See https://trello.com/c/6H24THnj/21-wakatime-time-tracking-for-ides-join-our-leaderboard


1. How long did the entire project (assignment 1) take you?
> answer...


2. What do you plan to do  differently in your development process for assignment 2?
> answer...
